DiDV = Spec300034{:,"y5A"}
Vbias = Spec300034{:,"xV"} 



figure(1)
hold on
plot(Vbias, DiDV, 'k-', 'MarkerFaceColor','b');
xlabel('Bias Voltage (V)');
ylabel('dI/dV');
%axis([0 410 10^2 10^10]);
box on
%set(gca, 'YScale', 'log');
set(gcf, 'Position', [200, 100, 600, 450])
set(gca, 'FontSize', 18)
hold off


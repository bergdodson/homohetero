\ init_r9.fs - 1.8.2
FALSE PhaseAcc1 pacc-locking

fvariable PTGTime 1.0e-5 PTGTime f!
fvariable PTGDriftTime 1.0e-3 PTGDriftTime f!
0 constant myfpgarecid

0 constant POSITIVE_POLARITY
1 constant NEGATIVE_POLARITY

FALSE HS1IN_AutoOffsEn
FALSE HS1OU_AutoOffsEn
FALSE HS2IN_AutoOffsEn
FALSE HS2OU_AutoOffsEn

FALSE LS1IN_AutoOffsEn
FALSE LS2IN_AutoOffsEn

\ 1.0e ProbeDrivePaccChan PhaseAcc1 pacc-syncfact!
\ ProbeDrivePaccChan PhaseAcc1 pacc-set-refchan
\ PhaseAcc1 pacc-res-all
\ 0.0e BiasPaccChan PhaseAcc1 pacc-syncfact!


true 0 dacdither
true 0 odacdither
$33333333 0 o-DitherDepth out
0 0 Dac1DitherDepth
0 0 Dac2DitherDepth

\ temporary fix for Bug 798
$20 ' statbit2pat phys2forth 3 cells + !

18 statbit-clr
19 statbit-clr
20 statbit-clr
21 statbit-clr
22 statbit-clr
23 statbit-clr

 ' r9_fdac1_v_0 alias fdac-1
 ' r9_fdac2_v_0 alias fdac-2

\ Initialise TTL as TTL 0 Out, TTL 1 In, TTL 2 Out, TTL 3 In
$5 CP2817-0 out 
: bitin ( paddr mask -- bitstatus )
  in  \ read from the TTL Line port address
 and \ and with mask to get only relavent bit
 0> \ Convert result to bool 0 or -1
 negate \ FORTH returns -1 for true convert to 1
;

\ Invert Z Polarity

: setPIPolarity ( cntrl polarity -- ) 
 \ check polarity and set multiplication factor
  POSITIVE_POLARITY = IF 1.0e0 ELSE -1.0e0 THEN ( cntrl ) ( f: polarity )
  fdup dup pi-sp ctrl-get fabs f* dup pi-sp ctrl-set ( cntrl ) ( f: polarity ) 
  fdup dup pi-P@ fabs f* dup pi-P! ( cntrl ) ( f: polarity )
  dup pi-I@ fabs f* pi-I! 
;

\ Delay Requires Time in tick, With procedure optimization referenced parameters are send as fvariables & need to convert fvariable to int
: GetTick ( f: seconds -- ) ( -- tick )
 samplefreq@ f* (  )   ( f: ticks )
 fround>u	( tick ) ( f: )
;

[ifdef] ScanProc1_XRes 
[else]
 variable ScanProc1_XRes 8 ScanProc1_XRes !
 variable ScanProc1_YRes 8 ScanProc1_YRes !
[then]
[ifdef] XCoordinateArray
[else] 
\ Array to store the spec X locations
 variable XCoordinateArray 1000 cells allot
\ Array to store the spec Y locations
 variable YCoordinateArray 1000 cells allot
 variable ArraySize 0 ArraySize !
\ This offset is used to check with the current pixel location
 variable ArrayOffset 0 ArrayOffset !
\ Return the address of the given index in the array
 : YCoordinate ( index -- addr )
	CELLS YCoordinateArray + 
 ;
 : XCoordinate ( index -- addr )
	CELLS XCoordinateArray + 
 ;
[then]



\ Yres and Grid can be taken from variables
: isYCoordAPixelStop ( Y GridIndex -- isStopLoctn? )
    dup 0= IF					( Y GridIndex EveryPixel? )
	  2drop TRUE					( true )
	ELSE
		dup 9 <= IF					( Y GridIndex 4To1024? )
			\ convert the GridIndex to Grid Res
		   2 swap ashift			( Y Grid )
		   ScanProc1_YRes @ swap / 	( Y dLn )
		   dup 2/ 					( Y dLn startLn )
		   rot 						( dLn startLn Y )
		   swap 					( dLn Y startLn )
		   \ the 1st stop line is different, subtract this out from Y.
		   -  						( dLn Y-startLn )
		   \ convert Y from 1 based Index to 0 based index
		   1-	 					( dLn Y-startLn-1 )
		   swap 					( posLn dLn ) 
		   \ if divisible it means that this is a line with a stop Location
		   mod  					( posLn_mod_dLn ) 
		   0=						( isStopLoctn? )
		ELSE
			\ Array Mode Check
			ArraySize @	0 <= 
			IF
				2drop FALSE				( FALSE )
			ELSE
				swap					( GridIndex Y )
				dup 					( GridIndex Y Y )
				\ subtract by 1 from loop index, array index starts from 0
				1-
				ArrayOffset @ YCoordinate @ = 
				IF 
					2drop TRUE
				ELSE
					2drop FALSE				( FALSE )
				THEN
			THEN
		THEN						( isStopLoctn? )
	THEN							( isStopLoctn? )
;

\ Xres and Grid can be taken from variables
: isXCoordAPixelStop ( X GridIndex -- isStopLoctn? )  ( 2 16 4 )
    dup 0= IF 					( X GridIndex EveryPixel? )
	  2drop TRUE						( true )
	ELSE
		dup 9 <= IF					( X GridIndex 4To1024? )
		   2 swap ashift
		   ScanProc1_XRes @ swap / 	( X dPx ) 
		   \ X 1st start pixel, subtract by 1 as in SPM100
		   dup 2/ 1- 				( X dPx startPx )
		   rot 						( dPx startPx X ) 
		   swap 					( dPx X startPx )
		   -    					( dPx X-startPx )
		   \ convert X from 1 based Index to 0 based index
		   1- 					( dPx X-startPx-1 )
		   swap 				( posPx dPx )
		   \ If they are divisible means current pixel could be a Stop Location
		   mod 
		   0= 					( isStopLoctn? )
		ELSE
		  \ Array Mode Check
			swap					( GridIndex X )
		    dup						( GridIndex X )
			\ X subtract by 1 from loop index, array index starts from 0
			1-
			ArrayOffset @ XCoordinate @ = 
			IF 
				\ Current pixel matches with the point in the array, Increment the array offset to the next point
				1 ArrayOffset @ + 
				ArraySize @ >= ( ArrayOffset ArraySize )
				IF
					\ Rest the Arrayoffset, after done with all points
					0 ArrayOffset !
				ELSE
					\ Increment offset by 1
					1 ArrayOffset @ + ArrayOffset !
				THEN
				2drop TRUE				( TRUE )
			ELSE
				2drop FALSE				( FALSE )
			THEN
		THEN
	THEN
;

\ XRes is taken from variables
: isXCoordALinePixelStop ( X GridIndex -- isStopLoctn? )  
	dup 6 <= IF					   ( X GridIndex 4To1024? )
	   2 swap ashift 1 -		   ( X GridSize )
	   ScanProc1_XRes @ 1 - swap / ( X dPx ) 
	   swap 1 - swap               ( X-1, dPx )     
	   \ If they are divisible means current pixel could be a Stop Location
	   mod 0= 				   	   ( isStopLoctn? )
	ELSE
	  \ Array Mode Check
	  2drop FALSE
	THEN
;

\ base @ decimal
\ : unr-sin-cos ( ScanProc -- ) ( f: -- sinphi cosphi )
\     Phi9Ctrl ctrl-get         ( )   ( f: phideg )
\     pi f* 180e f/             ( )   ( f: phirad )
\     fdup fsin fswap fcos      ( )   ( f: sinphi cosphi )
\ ;
\ base !

\ : unr-get-offsets ( ScanProc -- ) ( f: -- Xoffs Yoffs )
\     dup XO9Ctrl ctrl-get      ( ScanProc )   ( f: Xoffs )
\     YO9Ctrl ctrl-get          ( )            ( f: Xoffs Yoffs )
\ ;

\ : unr-action ( ScanProc -- ) ( f: X' Y' -- X Y )
    \ Subtract the offsets
\    dup unr-get-offsets       ( ScanProc ) ( f: X' Y' Xoffs Yoffs )
\    frot fswap f-             ( ScanProc ) ( f: X' Xoffs Y'-Yoffs )
\    frot frot f-              ( ScanProc ) ( f: Y'-Yoffs X'-Xoffs )
    \ Calc X and Y
\    unr-sin-cos               ( )          ( f: Y'-Yoffs X'-Xoffs sinphi cosphi )
\    2 fpick fover f*          ( )          ( f: Y'-Yoffs X'-Xoffs sinphi cosphi X'-Xoffs*cosphi )
\    4 fpick 3 fpick f* f+     ( )          ( f: Y'-Yoffs X'-Xoffs sinphi cosphi X )
\    frot frot                 ( )          ( f: Y'-Yoffs X'-Xoffs X sinphi cosphi )
\    4 froll f* fswap          ( )          ( f: X'-Xoffs X cosphi*Y'-Yoffs sinphi )
\    3 froll f* f-             ( )          ( f: X Y )
\ ;

\ : unrotate-coords  ( f: X' Y' -- X Y )
\     ScanProc1 unr-action  ( f: X Y )
\ ;

: safe-abort-bgnd? ( hook -- : aborted? )
	dup swp-running? if
		AbortCTXT
		TRUE
    else 
        drop 
		FALSE
	then
;
\ set the floating point precision to 10
10 to precision

[ifundef] ctxt-bury
    : dll>last ( elem -- lastelem )
    begin             ( elem )
        dup dll>next  ( thiselem nextelem )
        ?dup 0<>      ( thiselem nextelem flag )
    while             ( thiselem nextelem )
        nip       ( nextelem )
    repeat            ( thiselem)
    ;

    : ctxt-bury ( hook -- )
    dup @                      ( hook thisctxt )
    ?dup 0= abort" ctxt-bury: ctxt stack empty"
    over FreezeTopCTXT         ( hook thisctxt )
    over backupCTXT            ( hook thisctxt )
    dup dll>last               ( hook thisctxt lastctxt )
    2dup = if 2drop restoreCTXT exit then  
        >r 2dup swap dll-listrm r> ( hook thisctxt lastctxt )
    2dup dll-link !            ( hook thisctxt lastctxt )
    over dll-backlink !        ( hook thisctxt )
    0 swap dll-link !          ( hook )
    restoreCTXT                ( )
    ;
[then]

[ifdef] zuplim2
[else]
  fvariable zuplim2
  fvariable zlolim2
[then]

: slope/ f/ 100e f* ;
' slope/ Scaling-Operation-noname Piezocorr1 pzcr-X-Planefit !
' slope/ Scaling-Operation-noname Piezocorr1 pzcr-Y-Planefit !

Piezocorr1
dup XC9Ctrl over pzcr-X-Planefit @ 0 swap Scaling-link!
dup YC9Ctrl over pzcr-Y-Planefit @ 0 swap Scaling-link!
dup pzcr-X-Planefit @ scop-operand2@ over XD9Ctrl 0 swap Scaling-link!
dup pzcr-X-Planefit @ scop-operand1@ over
pzcr-Y-Planefit @ scop-operand1@ 0 swap Scaling-link!
dup pzcr-Y-Planefit @ scop-operand2@ over YD9Ctrl 0 swap Scaling-link!
dup pzcr-Y-Planefit @ scop-operand1@ over ZD9Ctrl 0 swap Scaling-link!
drop

ScanProc1 scp-xScaleIn 0 PiezoCorr1 pzcr-X-Planefit @ scop-operand2@
Scaling-link!
ScanProc1 scp-yScaleIn 0 PiezoCorr1 pzcr-Y-Planefit @ scop-operand2@
Scaling-link! 
ScanProc1 scp-zScaleIn 0 PiezoCorr1 pzcr-X-Planefit @ scop-operand1@
Scaling-link! 


Piezocorr1 XD9ctrl dup phys/FS@  Phys/FS!
Piezocorr1 YD9ctrl dup phys/FS@  Phys/FS!
Piezocorr1 ZD9ctrl dup phys/FS@  Phys/FS!

plotnum = 2;
quest1 = 'Do you want to select a new folder to import?';
answer1 = questdlg(quest1);
c = 0; % initializing the iteration variable
switch  answer1
    case 'Yes'
        [file,path] = uigetfile('*.txt');
        Filepath = strcat(path, file); 
        fileID = fopen(Filepath);
        C = textscan(fileID,'%s',10, 'headerlines', 12); %finds # of datapoints in a text file
        fclose(fileID);
        Ind = str2num(string(C{1}(4))); %Converts that to a double index
        A = importdata(Filepath, '\t', 36+Ind);
        Data.V = mat2cell(A.data(:,2), Ind, 1);  %next few lines are just reading imported data into a struct array and processing it.
        for c = 1:20
            Data.dIdV(c) = mat2cell(A.data(:,c+2), Ind, 1);
        end
    case 'No'
    otherwise
end

figure(1)
hold on
plot(cell2mat(Data.V), cell2mat(Data.dIdV(plotnum)), '-k');
axis([-inf inf -inf inf])
ylabel('dI/dV (A/V)');
xlabel('Bias Voltage (V)');
set(gca,'yTickLabel',[]);
box on
set(gca, 'YScale', 'log');
set(gcf, 'Position', [100, 100, 600, 450])
set(gca, 'FontSize', 18)
hold off

disp('Press a key to end program') 
pause; %holds program here until a button is pressed
close all; %closes all plots so you don't have to individually cross them out.
function varargout = STSAnalysis(varargin)
% STSANALYSIS MATLAB code for STSAnalysis.fig
%      STSANALYSIS, by itself, creates a new STSANALYSIS or raises the existing
%      singleton*.
%
%      H = STSANALYSIS returns the handle to a new STSANALYSIS or the handle to
%      the existing singleton*.
%
%      STSANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STSANALYSIS.M with the given input arguments.
%
%      STSANALYSIS('Property','Value',...) creates a new STSANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before STSAnalysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to STSAnalysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help STSAnalysis

% Last Modified by GUIDE v2.5 24-Feb-2022 17:08:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @STSAnalysis_OpeningFcn, ...
                   'gui_OutputFcn',  @STSAnalysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before STSAnalysis is made visible.
function STSAnalysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to STSAnalysis (see VARARGIN)

% Choose default command line output for STSAnalysis
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
handles.Data = struct();
handles.Offset = 1.0E-9; %initialize the offset value
set(handles.edit1, 'String', num2str(handles.Offset));
temp = {'ALD'; 'Thermal Oxide'; 'Conductive'; 'Other'};
set(handles.popupmenu4, 'String', temp);
import natsort.m.*
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% This sets up the initial plot - only do when we are invisible
% so window can get raised using STSAnalysis.


% UIWAIT makes STSAnalysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = STSAnalysis_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.

function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
quest1 = 'Do you want to select a new folder to import?';
answer1 = questdlg(quest1);
c = 0; % initializing the iteration variable
switch  answer1
    case 'Yes'
        path = uigetdir; %Brings up the GUI for selecting a folder to load everything from
        handles.saveAnalysisFilename = path;
        filepattern = fullfile(path, '*.txt'); %Sets the filepath and filetype that the directory search will return
        Filelist = dir(filepattern); %extracts all filenames in the given directory
        Filenames = cell(size(Filelist, 1), 1); %initializing 'Filenames' cell array
        Data = struct('Filename', [], 'Filepath', [], 'V', [], 'Vmin', 0.0, 'Vmax', 0.0, 'spec', struct); %makes a 'struct' known as 'Data' that is the same dimensions of the # of files in the selected folder
        for c = 1:size(Filenames,1)
            Filenames(c) =  cellstr(Filelist(c).name); %makes a cell array out of extracted file names which are strings so the names can be sorted properly
        end
        AnalysisBool = 0;
        for c = 1:size(Filenames, 1)
            if strcmp(Filenames(c), 'Analysis.txt') == 1%finds out the analysis text file index to remove it from the list.
                AnalysisIndex = c;
                AnalysisBool = 1;
            else
            end
        end

        if AnalysisBool == 1
            Filenames(AnalysisIndex) = [];  %Analysis file removal from filenames list
        else
        end

        Filenames = natsort(Filenames); %imported from matlab website, sorts filenames properly by the number so instead of 1, 10, 11, ... we get 1, 2, 3
        SizeTable = table('Size', [size(Filenames, 1) 1], 'VariableTypes', {'double'});
        for c = 1:size(Filenames,1)
            Filenames(c)
            Data(c).Filename = Filenames(c); %changing sorted file name back to string
            Data(c).Filepath = strcat(path, '\', string(Data(c).Filename)); %creating a full file path out of the strings
            fileID = fopen(Data(c).Filepath);
            C = textscan(fileID,'%s',10, 'headerlines', 12); %finds # of datapoints in a text file
            fclose(fileID);
            Ind = str2num(string(C{1}(4))); %Converts that to a double index
            A1 = importdata(Data(c).Filepath, '\t', 20); %2 data import calls because the 'importdata' function was stopping in the middle of files where theres text and headers for dIdV
            A2 = importdata(Data(c).Filepath, '\t', 36 + Ind);
            Data(c).V = A1.data(:,2);  %Imports Voltage data
            Data(c).Vmin = min(A1.data(:,2));
            Data(c).Vmax = max(A1.data(:,2));
            pointCount = size(Data(c).V, 1);
            halfCount1 = round(pointCount/2, 0); %finds the middle point rounding it to the nearest whole number.
            halfCount2 = halfCount1+1;
            for j = 1:20
                if size(A1.data,2) < j+2 %this checks to see if one of the spectra is all zeros and does not record it in memory if it is.
                    break;
                else
                    Data(c).spec(j).I = A1.data(:, j+2); %A substructure is used to store the 20 I and dIdV curves
                    Data(c).spec(j).dIdV = A2.data(:, j+2);
                    %initializing fitting indices
                    Data(c).spec(j).BG1 = 1;
                    Data(c).spec(j).BG2 = halfCount1;
                    Data(c).spec(j).CBM1 = halfCount2;
                    Data(c).spec(j).CBM2 = pointCount;
                end
            end
            SizeTable.Var1(c) = size(Data(c).spec, 2); %collects number of sweeps in each spectra set
            TempString = string(zeros(size(Data(c).spec, 2), 1));%initializing temporary string array
            for j = 1: size(TempString, 1)
                TempString(j) = string(j); % filling temporary string array for the list of spectra.
            end
            Data(c).list = TempString;  %Assigning string array to list field of Data struct
        end
    case 'No'
        handles.saveAnalysisFilename = pwd;
    otherwise
        handles.saveAnalysisFilename = pwd;
end
t = table('Size', [size(Filenames, 1) 4], 'VariableTypes', {'cellstr', 'double', 'double', 'double'});
temp = struct2table(Data); 
t(:, {'Var1', 'Var2', 'Var3'}) = temp(:,  {'Filename', 'Vmin', 'Vmax'}); %adds file name vmin and vmax to the exporting table
t(:, {'Var4'}) = SizeTable(:, {'Var1'});% adding on number of spectra per file
cellTemp = table2cell(t); %converts the table to a cell array which is all the uitable object accepts.
StringTemp = string(t.Var1);

%This part communicates values to the gui
set(handles.uitable2, 'Data', cellTemp); %updating the uitable with the values from the import
set(handles.popupmenu2, 'String', StringTemp); %updating the file name dropdown
set(handles.popupmenu3, 'String', Data(1).list); %updating the spectra list dropdown
handles.Data = Data; %makes a 'handles' parented structure to be exported to the main environment outside this function
set(handles.text1, 'String', path);
%plot for current
CurrentPlot(hObject, eventdata, handles, 1);
%plot for dIdV
dIdVPlot(hObject, eventdata, handles, 1);
%Do initial fit for first data points
FitCall(hObject, eventdata, handles, 1, 1);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushbutton1.
function pushbutton1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
quest1 = 'Do you want to import an analysis file (this will overwrite the current table data)?';
answer1 = questdlg(quest1);
switch  answer1
    case 'Yes'
        [file,path] = uigetfile('*.txt');
        Filepath = strcat(path, file); 
        fileID = fopen(Filepath);
        A = importdata(Filepath, '\t', 36+Ind);
        Data.V = mat2cell(A.data(:,2), Ind, 1);  %next few lines are just reading imported data into a struct array and processing it.
        for c = 1:20
            Data.dIdV(c) = mat2cell(A.data(:,c+2), Ind, 1);
        end
    case 'No'
    otherwise
end

% --- Executes during object creation, after setting all properties.
function uitable2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

c = get(handles.popupmenu2, 'Value'); %Grabs index from the dropdown of file selection
set(handles.popupmenu3, 'String', handles.Data(c).list); %Updates the spectrum number list with available options;

%plot for current
CurrentPlot(hObject, eventdata, handles, c);

%plot for dIdV
dIdVPlot(hObject, eventdata, handles, c)

%Updates fitting window
set(handles.popupmenu3, 'Value', 1)
FitCall(hObject, eventdata, handles, c, 1);


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: place code in OpeningFcn to populate axes1



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
handles.Offset = str2double(get(hObject, 'String'));
disp(handles.Offset);
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list

FitCall(hObject, eventdata, handles, c, k);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3 which is for picking a new spectrum.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list

FitCall(hObject, eventdata, handles, c, k);


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function CurrentPlot(hObject, eventdata, handles, c)
axes(handles.axes3)
cla;
hold on
for j = 1:size(handles.Data(c).spec, 2)
    plot(handles.Data(c).V, abs(handles.Data(c).spec(j).I));
end
set(handles.axes3, 'XLim', [-inf inf]);
set(handles.axes3, 'YScale', 'log');
hold off

function dIdVPlot(hObject, eventdata, handles, c)
axes(handles.axes4)
cla;
hold on
for j = 1:size(handles.Data(c).spec, 2)
    plot(handles.Data(c).V, handles.Data(c).spec(j).dIdV);
end
set(handles.axes4, 'XLim', [-inf inf]);
set(handles.axes4, 'YScale', 'log');
hold off

function FitCall(hObject, eventdata, handles, c, k)
logdIdV = log(handles.Data(c).spec(k).dIdV);

%retrieving fit ranges based on their index in the voltage array
BG1 = handles.Data(c).spec(k).BG1;
set(handles.edit2, 'String', num2str(handles.Data(c).V(BG1)));
BG2 = handles.Data(c).spec(k).BG2;
set(handles.edit3, 'String', num2str(handles.Data(c).V(BG2)));
CBM1 = handles.Data(c).spec(k).CBM1;
set(handles.edit6, 'String', num2str(handles.Data(c).V(CBM1)));
CBM2 = handles.Data(c).spec(k).CBM2;
set(handles.edit7, 'String', num2str(handles.Data(c).V(CBM2)));

%making subarrays for fitting
X1 = handles.Data(c).V(BG1:BG2); 
Y1 = logdIdV(BG1:BG2);
X2 = handles.Data(c).V(CBM1:CBM2);
Y2 = logdIdV(CBM1:CBM2);
Fit1 = fitlm(X1, Y1);
Fit2 = fitlm(X2, Y2);

%These lines just put the fit parameters in easy to call variables for Eb and error calculation.
b1 = Fit1.Coefficients{1, 'Estimate'};
db1 = Fit1.Coefficients{1, 'SE'};
a1 = Fit1.Coefficients{2, 'Estimate'};
da1 = Fit1.Coefficients{2, 'SE'};
b2 = Fit2.Coefficients{1, 'Estimate'};
db2 = Fit2.Coefficients{1, 'SE'};
a2 = Fit2.Coefficients{2, 'Estimate'};
da2 = Fit2.Coefficients{2, 'SE'};
Eb = (b2-b1)/(a1-a2);
temp1 = 1/(a1-a2); %partial derivative with respect to b1 or b2
temp2 = (b2-b1)/(a1-a2)^2; % partial derivative with respect to a1 or a2
dEb = sqrt((db1*temp1)^2 + (db2*temp1)^2 + (da1*temp2)^2 + (da2*temp2)^2);

%making the data into a cell array and updating the fit table object
C = {a1, da1;
    b1, db1;
    a2, da2;
    b2, db2;
    Eb, dEb};
set(handles.uitable3, 'Data', C); 

f1 = @(x) a1*x + b1;
f2 = @(x) a2*x + b2;

axes(handles.axes5)
cla;
hold on
lnfunc = plot(handles.Data(c).V, logdIdV, '-k');
fplot(f1, [min(handles.Data(c).V(BG1), handles.Data(c).V(BG2)) max(handles.Data(c).V(BG1), handles.Data(c).V(BG2))], '-r');
fplot(f2, [min(handles.Data(c).V(CBM1), handles.Data(c).V(CBM2)) max(handles.Data(c).V(CBM1), handles.Data(c).V(CBM2))], '-b')
set(handles.axes5, 'XLim', [-inf inf]);
set(handles.axes5, 'YLim', [min(logIdV) max(logIdV)]);
hold off

function UpdateStats(hObject, eventdata, handles)
tempCell1 = get(handles.uitable2, 'Data');

tempCell2 = tempCell1(:, 7);
tempString1 = tempCell2(~cellfun('isempty', tempCell2(:, 1)));
tempString1 = string(tempString1);
disp(tempString1)
[tempCount1, tempCountGroups] = groupcounts(tempString1);
indALD = find(contains(tempCountGroups,'ALD'));
indTherm = find(contains(tempCountGroups, 'Thermal Oxide'));
indCond = find(contains(tempCountGroups, 'Conductive'));
indOther = find(contains(tempCountGroups, 'Other'));
nCat = size(tempString1, 1);
if isempty(indALD) == 1
    nALD = 0;
    covALD = 0;
    dcovALD = 0;
else
    nALD = tempCount1(indALD);
    covALD = nALD/nCat;
    dcovALD = sqrt((1-covALD)*covALD/nCat);
end

if isempty(indTherm) == 1
    nTherm = 0;
    covTherm = 0;
    dcovTherm = 0;
else
    nTherm = tempCount1(indTherm);
    covTherm = nTherm/nCat;
    dcovTherm = sqrt((1-covTherm)*covTherm/nCat);
end

if isempty(indCond) == 1
    nCond = 0;
    covCond = 0;
    dcovCond = 0;
else
    nCond = tempCount1(indCond);
    covCond = nCond/nCat;
    dcovCond = sqrt((1-covCond)*covCond/nCat);
end

if isempty(indOther) == 1
    nOther = 0;
    covOther = 0;
    dcovOther = 0;
else
    nOther = tempCount1(4);
    covOther = nOther/nCat;
    dcovOther = sqrt((1-covOther)*covOther/nCat);
end

tempCell2 = tempCell1(:, 5:7); %importing Eb, Eb errors, and category values
removeIndex = strcmp(tempCell2(:,3), 'ALD'); %makes a boolean list of rows with 'ALD' in them
tempCell2(~removeIndex,:) = []; % tilde (~) inverts array and uses that to remove any rows without 'ALD'

EbMat = cell2mat(tempCell2(:,1));
dEbMat = cell2mat(tempCell2(:,2));
avgEb = mean(EbMat);
randErr = std(EbMat)/sqrt(size(dEbMat, 1)); %Std. Error equation
instErr = sqrt(sum(dEbMat.^2))/size(dEbMat, 1);
EbStdErr = sqrt(randErr^2 + instErr^2);

C = {nCat, avgEb, EbStdErr;
    nALD, 100*covALD, 100*dcovALD;
    nTherm, 100*covTherm, 100*dcovTherm;
    nCond, 100*covCond, 100*dcovCond;
    nOther, 100*covOther, 100*dcovOther};
set(handles.uitable4, 'Data', C); 

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list
UserEntry = str2double(get(hObject, 'String'));
[val, idx] = min(abs(handles.Data(c).V - UserEntry));
handles.Data(c).spec(k).BG1 = idx;
set(handles.edit2, 'String', num2str(handles.Data(c).V(idx)));

FitCall(hObject, eventdata, handles, c, k);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list
UserEntry = str2double(get(hObject, 'String'));
disp(2)
[val, idx] = min(abs(handles.Data(c).V - UserEntry));
handles.Data(c).spec(k).BG2 = idx;
set(handles.edit3, 'String', num2str(handles.Data(c).V(idx)));

FitCall(hObject, eventdata, handles, c, k);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list
UserEntry = str2double(get(hObject, 'String'));
[val, idx] = min(abs(handles.Data(c).V - UserEntry));
handles.Data(c).spec(k).CBM1 = idx;
set(handles.edit6, 'String', num2str(handles.Data(c).V(idx)));

FitCall(hObject, eventdata, handles, c, k);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list
UserEntry = str2double(get(hObject, 'String'));
[val, idx] = min(abs(handles.Data(c).V - UserEntry));
handles.Data(c).spec(k).CBM2 = idx;
set(handles.edit7, 'String', num2str(handles.Data(c).V(idx)));

FitCall(hObject, eventdata, handles, c, k)
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.



% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4


% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(handles.popupmenu2, 'Value'); %get the file number from the dropdown list
k = get(handles.popupmenu3, 'Value'); %get the spectrum number from the dropdown list
tempCell1 = get(handles.uitable3, 'Data'); %gets Eb and fit parameter data.
tempCell2 = get(handles.uitable2, 'Data'); %gets full data table;
tempStr = convertStringsToChars(get(handles.popupmenu4, 'String'));%This has to be done to categorize the data.
Selection = get(handles.popupmenu4, 'Value');

disp(tempStr)
disp(Selection)
tempCell2{c, 5} = tempCell1{5, 1};
tempCell2{c, 6} = tempCell1{5, 2};
tempCell2{c, 7} = tempStr{Selection};
tempCell2{c, 8} = k;
set(handles.uitable2, 'Data', tempCell2);
UpdateStats(hObject, eventdata, handles);
guidata(hObject,handles) %updates the main UI with the Data structure using the 'handles' parent.


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
FolderAnalysisFilename = fullfile(handles.saveAnalysisFilename,'AnalysisFolder','EbAnalysis.xlsx');

%Creating the data versions of the Eb tables
saveTable2 = table; %Variable that will be filled with the data from uitable2
saveTable4 = table; %Variable that will be filled with the data from uitable4

%Creating a matching version of uitable2
columnNames2 = strrep(handles.uitable2.ColumnName,' ','');
for x = 1:numel(columnNames2)
    saveTable2.(columnNames2{x}) = {handles.uitable2.Data{:,x}}';
end

% Creating a matching version of uitable4
    %Column names
columnNames4 = strrep(handles.uitable4.ColumnName,' ','');
    %Row names
saveTable4.Row1 = handles.uitable4.RowName;
for x = 1:numel(columnNames4)
    saveTable4.(columnNames4{x}) = {handles.uitable4.Data{:,x}}';
end
%Saving the tables
if ~exist(fullfile(handles.saveAnalysisFilename,'AnalysisFolder'),"dir")
    mkdir(fullfile(handles.saveAnalysisFilename,'AnalysisFolder'))
end

writetable(saveTable2, FolderAnalysisFilename, 'Sheet', 'FileEbs')
writetable(saveTable4, FolderAnalysisFilename, 'Sheet', 'NetEbs')

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,saveFolder] = uiputfile(fullfile(handles.saveAnalysisFilename,'EbAnalysis.xlsx'));
FolderAnalysisFilename = fullfile(saveFolder,filename);

%Creating the data versions of the Eb tables
saveTable2 = table; %Variable that will be filled with the data from uitable2
saveTable4 = table; %Variable that will be filled with the data from uitable4

%Creating a matching version of uitable2
columnNames2 = strrep(handles.uitable2.ColumnName,' ','');
for x = 1:numel(columnNames2)
    saveTable2.(columnNames2{x}) = {handles.uitable2.Data{:,x}}';
end

% Creating a matching version of uitable4
    %Column names
columnNames4 = strrep(handles.uitable4.ColumnName,' ','');
    %Row names
saveTable4.Row1 = handles.uitable4.RowName;
for x = 1:numel(columnNames4)
    saveTable4.(columnNames4{x}) = {handles.uitable4.Data{:,x}}';
end
%Saving the tables
if ~exist(fullfile(handles.saveAnalysisFilename,'AnalysisFolder'),"dir")
    mkdir(fullfile(handles.saveAnalysisFilename,'AnalysisFolder'))
end

writetable(saveTable2, FolderAnalysisFilename, 'Sheet', 'FileEbs')
writetable(saveTable4, FolderAnalysisFilename, 'Sheet', 'NetEbs')

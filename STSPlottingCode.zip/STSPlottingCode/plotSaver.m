function [] = plotSaver(figures,data,type)

%Create filenames


%Save figures
for x = 1:numel(figures)
    if type == 1
        nameRoot = strcat(data(x).filepath(1:end-4),'_CUR Current_Scan ',string(x));
    elseif type == 2
        nameRoot = strcat(data(x).filepath(1:end-4),'_LIA Current_Scan ',string(x));
    elseif type == -1
        nameRoot = strcat(data(x).filepath(1:end-4),'_Overlayed');
    elseif type == -2
        nameRoot = strcat(data(x).filepath(1:end-4),'_OverlayedDirectory');
    else
        nameRoot = strcat(data(x).filepath(1:end-4),'_plotwindow ',string(x));
    end
    
    %Saving the figure as a .fig and other picture format
    saveNameSVG = strcat(nameRoot,'.png');
    saveNameFIG = strcat(nameRoot,'.fig');
    saveas(figures(x),saveNameSVG)
    saveas(figures(x),saveNameFIG)

end

end
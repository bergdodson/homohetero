function [passback] = multiplot(plotsarr)
%initialize the multiplot
multiPlot = struct;
multiPlot(1).f = figure; clf(multiPlot(1).f)
multiPlot.ax = axes('Parent', multiPlot(1).f,'NextPlot','add');

% numPlots = numel(plotsarr(1,:));
numPlots = numel(plotsarr);
%Setting up Plot Colors
if numPlots == 1
    color = [0,0,0];
    dColor = [0 0 0];
elseif numPlots > 1
    color = [0,0,1];
    dColor = 1/(numPlots - 1);
end

%Plotting
xmin = 0;
xmax = 0;
overlayPlots = [];
for x = 1:numPlots
    % if mod(x,2) == 1
    %     linSty = '-';
    % elseif mod(x,2) == 0
    %     linSty = ':';
    % else
    %     disp('Line Style number is neither even or odd')
    % end
    linSty = '-';
   
    % plot(plotsarr(1,x).XData,plotsarr(1,x).YData, linSty,'Color',color)  
    overlayPlots(x) = plot(plotsarr(x).XData,abs(plotsarr(x).YData), linSty,'Color',color);  
    
    %updating x-limits for the plot
    if min(plotsarr(x).XData) < xmin
        xmin = min(plotsarr(x).XData);
    end

    if max(plotsarr(x).XData) > xmax
        xmax = max(plotsarr(x).XData);
    end

    % Updating the Color for next plot
    color = abs(color + [dColor,0,-dColor]);
    logicalColorFloor = color < dColor;
    logicalColorCieling = color > 1;
    color(logicalColorFloor) = 0;
    color(logicalColorCieling) = 1;
end

%Adding axes stuff
box on
yscale log
set(multiPlot.ax, 'YGrid','on')
set(multiPlot.ax, 'Fontsize',28)
% set(multiPlot.f,'Position',[100, 100, 700, 500])

%Yaxis Properties
ylim([1e-11,2e-7])
set(multiPlot.ax, 'YTick', [1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7])
set(multiPlot.ax,'YTickLabel',{'10^{-13}','10^{-12}','10^{-11}','10^{-10}','10^{-9}','10^{-8}','10^{-7}'})
ylabel('dI/dV (Arb. Units)')

%Xaxis Properties
xstep = max(floor(abs(xmax - xmin)/2) * 0.5, 0.5);
xticks = floor(xmin):xstep:ceil(xmax);

xlim([xmin xmax])
set(multiPlot.ax,'XTick',xticks)
set(multiPlot.ax,'XTickLabel', string(num2cell(xticks)))
xlabel('Voltage (V)')

set(multiPlot.f,'Position',[100, 100, 700, 500])
% %Setting up the color bar
% num_steps = numPlots;
% gradient_map = zeros(num_steps, 3);
% for i = 1:num_steps
%     gradient_map(i, :) = [(i-1)/(num_steps-1), 0, 1 - (i-1)/(num_steps-1)];
% end
% colormap(gradient_map);
% 
% %Ticks for the Gradient bar
% if num_steps > 2
%     colorbar(multiPlot.ax,'eastoutside','TickLabels',{'1',string(floor(numPlots/2)),string(numPlots)},'Ticks',[0,floor(numPlots/2), numPlots])
% elseif num_steps == 2
%     colorbar(multiPlot.ax,'eastoutside','TickLabels',{'1','2'},'Ticks',[0,1])
% end

legend(overlayPlots,'FontSize',18,'Location','northwest')

passback = multiPlot(1).f;
end
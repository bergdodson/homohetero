%STS plotting

%initialize
clear; close all;

[codingDir, STSfiles] = DirMapping('Plot');
plotsarrCUR = [];
figuresarrCUR = [];
plotsarrLIA = [];
figuresarrLIA = [];
%For each Directory here is what to plot and how to do it
for x = 1:numel(STSfiles)
    %importing data
    expectedTables = {"Cur: Current","LIA: Current", "Top: Z PI Output"};
    expectedTableHeader = {'Y_pixel', '1x s'};
    data = Data_Import(fullfile(STSfiles(x).folder,STSfiles(x).name),expectedTableHeader,expectedTables);
    
    %plotting data
    for y = 1:numel(data) %Plotting the Curruent IV, and then LIA IV plots for each file in the directory
        % Individual Scans 
        [plots,figures] = STSDataPlotting(data{y});
        plotSaver(figures,data{y},y);
        
        %Collect the Curr and LIA plots into a plotting array
        if mod(y,2)== 1
            plotsarrCUR = [plotsarrCUR;plots];
            figuresarrCUR = [figuresarrCUR;figures]; 
        elseif mod(y,2)== 0
            plotsarrLIA = [plotsarrLIA;plots];
            figuresarrLIA = [figuresarrLIA;figures]; 
        end

        % Overlayed plots for files that have more than 1 sweep
        % if mod(y,2) == 1
        %     fileOverlay = struct('filepath',strcat(data{y}(1).filepath(1:end-4),'_CUR Current.txt'));
        % elseif mod(y,2) == 0
        %     fileOverlay = struct('filepath',strcat(data{y}(1).filepath(1:end-4),'_LIA Current.txt'));
        % end
        % multifig = multiplot(plots);
        % plotSaver(multifig,fileOverlay,-1);

        % close all;
    end
    
% % overlay the plots from all the files in the directory
% multiFileFig = multiplot(plotsarrLIA);
% folderStruct = struct('filepath',strcat(data{y}(1).filepath(1:end-4)));
% plotSaver(multiFileFig,folderStruct,-2);
% 
% %Clear the variables for the next directory
% plotsarrLIA = [];
% figuresarrLIA = [];
% 
% %close all the open plots so the next 
% close all;

end

% overlay the plots from all the files in the directory
multiFileFig = multiplot(plotsarrLIA);
folderStruct = struct('filepath',strcat(data{y}(1).filepath(1:end-4)));
plotSaver(multiFileFig,folderStruct,-2);

%Clear the variables for the next directory
plotsarrLIA = [];
figuresarrLIA = [];

%close all the open plots so the next 
close all;

'break'
% close all;
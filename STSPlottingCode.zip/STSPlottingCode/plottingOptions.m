function [figureOpts, axesOpts] = plottingOptions(data)

% minx = 0;
% maxx = 0;

for x = 1:numel(data)
    if exist('minx','var') 
        if min(data(x).V) < minx
            minx = min(data(x).V);
        end

        if max(data(x).V) > maxx
            maxx = max(data(x).V);
        end
    else
        minx = min(data(x).V);
        maxx = max(data(x).V);
    end
end
axesKeys = ["XLabel", "YLabel", "XLim", "Box", "FontSize","YScale",...
    "YLim","YTick","YTickLabel",...
    "XTick","XTickLabel"];
axesValues = {'Voltage (V)','Current (A)',[minx,maxx] + [-1,1]*range([minx,maxx]).* 0.05, 'on',28,'Log',...
    [1e-13,2e-7], [1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7], {'10^{-13}','10^{-12}','10^{-11}','10^{-10}','10^{-9}','10^{-8}','10^{-7}'},...
    [-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10], {'-10','-9','-8','-7','-6','-5','-4','-3','-2','-1','0','1','2','3','4','5','6','7','8','9','10'}};
% close all;
axesOpts = dictionary(axesKeys, axesValues);

figKeys = ["Position"];
figValues = {[100, 100, 600, 500]};
figureOpts = dictionary(figKeys, figValues);


end
function [plots, figurearray] = STSDataPlotting(Data)
[figOpts,axeOpts] = plottingOptions(Data);

%plots = cell(numel(Data),numel(Data(1).I.Properties.VariableNames));
figurearray = [];

for x = 1:numel(Data) % cycle through the current and the LIA data
    %Getting the specific sweeps to be plotted
    sweeps = Data(x).I.Properties.VariableNames; %Cell array

    for y = 1:numel(sweeps) %cycle through all the scan sweeps
        curPlot = figure;
        curAxe = gca;

        %plotting
        plots(x,y) = plot(Data(x).V, abs(Data(x).I.(sweeps{y})), 'k', LineWidth=1);
        
        %Setting the figure options
        figOptsFieldnames = keys(figOpts);
        for z = 1:numel(figOptsFieldnames)
            set(curPlot, figOptsFieldnames{z}, figOpts{figOptsFieldnames{z}})
        end

        %Setting the axes options
        axeOptsFieldnames = keys(axeOpts);
        for z = 1:numel(axeOptsFieldnames)
            if axeOptsFieldnames{z} == "XLabel" || axeOptsFieldnames{z} == "YLabel" 
                label = curAxe.(axeOptsFieldnames{z});
                label.String = axeOpts{axeOptsFieldnames{z}};
            
            else
            set(curAxe, (axeOptsFieldnames{z}), axeOpts{axeOptsFieldnames{z}});
            
            end
        end

        if ceil( log10( max(abs( Data(x).I.(sweeps{y}) )) )) < -12
            ymax = 2e-12;

        else
            ymax = 10^(ceil( log10( max(abs( Data(x).I.(sweeps{y}) )) )));
        end

        ylim([1e-12, ymax])
        figurearray(x,y) = curPlot;
    end
end

end
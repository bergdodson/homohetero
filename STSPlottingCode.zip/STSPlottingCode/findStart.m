function [linenumbers,varHeadder] = findStart(filepath,colHeader,tableID)

linenumbers = -1;

if numel(tableID)>1
    [linenumbers,varHeadder] = multitable(filepath,colHeader,tableID);
elseif numel(tableID) == 1
    linenumbers = singletable(filepath,colHeader);
end
end

function linenums = singletable(filepath, colHeader, ~)
% Scannable read-in of data file
fileText = readlines(filepath);
linenums = [-1,-1];
readtable = 0;

for x = 1:numel(fileText)
if contains(fileText(x),colHeader)
    linenums(1) = x+1;
    readtable = 1;
elseif readtable && isempty(regexpi(fileText(x), "\d","once"))
    linenums(2) = x-1;
    readtable = 0;
end
end

end

function [linenumbers,varHeadder] = multitable(filepath,colHeader,tableID)
%Get the scannable file
fileText = readlines(filepath);

%Initialize the variables for reading table 
linenums = zeros([2, numel(tableID)]); %row 1 for the start of the table, row 2 for the end of the table
tableRead = 0;

%Initialize the variables for table order
tableOrder = zeros([1, numel(tableID)]);
tableSet = 1;

varHeadder = "";
varHeadderFound = 0;

% Looping through each of the imported data files text lines to see if they are header or are data and which table they belong to
try
for x = 1:numel(fileText)
    %Reading to see if a table will be coming up
    queryNum = 1;
    for y = 1:numel(tableID) 
        if contains(fileText(x), tableID{y}) && ~contains(fileText(x), "bias")
        tableOrder(tableSet) = y;  
        break;
        end
    end
    
    %Reading to see if a table is starting or ending
    queryNum = 2;
    if ~tableRead && contains(fileText(x), colHeader)
        linenums(1,tableSet) = x+1;
        tableRead = 1;

    elseif tableRead && isempty(regexpi(fileText(x), "\d","once"))
        linenums(2,tableSet) = x-1;
        tableRead = 0;
        tableSet = tableSet + 1;
    end

    %Reading to get the number of scans in the file
    queryNum = 3;
    if ~varHeadderFound && (contains(fileText(x), '1x V') || contains(fileText(x), '1x s')) %testing to see which header has been found
        varHeadder = strtrim(split(fileText(x), [char(9),'1']));
        varHeadder = varHeadder(2:end);
        varHeadder = erase(varHeadder," ");
        varHeadder = varHeadder';
        varHeadderFound = true;
    end

end
catch
    sprintf('the problem happened on iteration %d while looking at query # %d',x,queryNum)
end

linenums2 = zeros([2, numel(tableID)]); %row 1 for the start of the table, row 2 for the end of the table
for x = 1:tableSet-1
    destination = tableOrder(x);
    moving = linenums(1:2,x);
    linenums2(1:2,destination) = moving; 
    tableSet = tableSet + 1;
end

%Removing unfound table index spaces
%Table is a row, 1 st column is start of table, 2nd column is the end of the the table
linenumbers = linenums2'; %Transposing the linenumbers to work with readtable in the data_import function
% tableInd = linenumbers > 0;
nonZeroTableVals = nonzeros(linenumbers');
linenumbers = reshape(nonZeroTableVals,2,numel(nonZeroTableVals)/2)';

end
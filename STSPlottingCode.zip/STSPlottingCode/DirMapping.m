function [codingDir, STSFiles] = DirMapping(IVFileID) %IVFileID (CharArr_TheCharsInFileNamesThatAreShared)


codingDir = pwd; %identify the file with all the matlab code
cd .. %Move to the folder with all the folders to analyze
directory = dir; %Image the folder with all the IV run folders
cd (codingDir); %Return to the matlab folder

files = zeros(numel(directory),1);
for x = 1:numel(directory)
    if directory(x).isdir %Is it a folder
        if ~isempty(strfind(directory(x).name,IVFileID))%Does the file name match the IV run naming convention
            files(x) = true;
        end
    end
end
STSDir = directory(logical(files)); %These are the files that are IV runs

STSFiles = dir;
STSFiles = STSFiles(1);
STSFiles(1) = [];

for x = 1:numel(STSDir)
    if ~isempty(dir(fullfile(STSDir(x).folder, STSDir(x).name,'*.txt')))
        STSFiles = [STSFiles; dir(fullfile(STSDir(x).folder, STSDir(x).name, '*.txt'))];
    end
end
end
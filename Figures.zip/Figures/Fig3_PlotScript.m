figure(1)
hold on
MarkSz = 22;
errorbar(F3A_Eb, F3A_EbErr, '.','Color',  [0 0 0], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
axis([0.5 numel(F3A_Eb)+0.5 min(F3A_Eb)*0.90 max(F3A_Eb)*1.10]);
%xlabel('V_{bg}');
%set(gca, 'YScale', 'log');
ylabel('E_{b} (eV)');
%yticks([1e2 1E3 1E4 1E5 1E6]);
yyaxis right
errorbar(F3A_ALDCov, F3A_ALDCovErr, '.', 'Color', [0 0 1], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
ylabel('ALD Coverage (%)', 'Color', 'k');
axis([0.5 numel(F3A_Eb)+0.5 -5 105])
yticks([0 20 40 60 80 100]);
set(gca,'XTickLabel',[]);
set(gca, 'YColor', 'k');
legend('E_{b}', 'ALD Coverage');
set(gcf, 'Position', [1000, 100, 900, 450])
set(gca, 'FontSize', 24)
box on
hold off

disp('Press a key to end program')  
pause; %holds program here until a button is pressed
close all; %closes all plots so y  ou don't have to individually cross them out.


figure(1)
hold on
MarkSz = 22;
plot(F2A_LRS, '.','Color',  [1 0 0], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
plot(F2A_HRS, '.','Color',  [0 0 1], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
axis([0.5 numel(F2A_LRS)+0.5 min(F2A_LRS)*0.5 max(F2A_HRS)*2]);
%xlabel('V_{bg}');
set(gca, 'YScale', 'log');
ylabel('Resistance (\Omega)');
yticks([1e2 1E3 1E4 1E5 1E6]);
yyaxis right
plot(F2A_Yield, '.', 'Color', [0 0 0 ], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
ylabel('Yield (%)', 'Color', 'k');
axis([0.5 numel(F1B_HRS)+0.5 -5 105])
set(gca,'XTickLabel',[]);
set(gca, 'YColor', 'k');
yticks([0 20 40 60 80 100]);
box on
set(gcf, 'Position', [200, 400, 1000, 450])
set(gca, 'FontSize', 24) 
hold off


figure(2)
hold on
plot(F2B_Speed, '.','Color',  [0 0 0], 'LineWidth', 2.5, 'MarkerSize', MarkSz);
axis([0.5 numel(F2B_Speed)+0.5 min(F2B_Speed)*0.5 max(F2B_Speed)*1.5]);
%xlabel('V_{bg}');
set(gca, 'YScale', 'log');
ylabel('Switching Speed (s)');
yticks([1e-9 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 1e-2]);
set(gca,'XTickLabel',[]);
box on
set(gcf, 'Position', [300, 400, 985, 450])
set(gca, 'FontSize', 24) 
hold off


disp('Press a key to end program')  
pause; %holds program here until a button is pressed
close all; %closes all plots so y  ou don't have to individually cross them out.
